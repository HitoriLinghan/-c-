#include <stdio.h>
int main()
{
    float h;
    int count=0;
    scanf("%f",&h);
    do
    {
        h=h*3/4;
        count++;
    } while (h>1);
    printf("count=%d\n",count);
    return 0;
}
