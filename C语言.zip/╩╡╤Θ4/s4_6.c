#include <stdio.h>
int main()
{
    int i,n;
    long s=0,t=1;
    printf(" \n input n: ");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        t=t*i;
        s=s+t;
    }
    printf("......=%d\n",s);
}