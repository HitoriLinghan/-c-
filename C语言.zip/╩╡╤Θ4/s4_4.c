#include <stdio.h>
int main()
{
    int i,s,n;
    s=1;
    n=5;
    for (i=1;i<=n;i++)
        s*=i;
    printf("%d!=%d\n",n,s);   
    return 0;
}