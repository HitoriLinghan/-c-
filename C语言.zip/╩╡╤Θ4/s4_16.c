#include <stdio.h>

int main()
{
    int n=1;
    double e=1.0, term=1.0;
    while (term > 1e-6) {
        term /= n++;
        e+=term;
    }
    printf("e=%f\n",e);
    return 0;
}