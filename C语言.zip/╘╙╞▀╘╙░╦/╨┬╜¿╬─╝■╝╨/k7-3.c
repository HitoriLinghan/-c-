#include <stdio.h>

main () {
	int score,x;
	scanf("%d", &score);
	x=score/10;
	switch(x)
{case 10:
case 9:printf("�ȼ�A\n");break;
case 8:printf("�ȼ�B\n");break;
case 7:printf("�ȼ�C\n");;break;
case 6:printf("�ȼ�D\n");break;
default:printf("�ȼ�E\n");break;
}
}
