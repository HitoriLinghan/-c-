#include<stdio.h>
main()
{
	int a,b,t;
	scanf("%d%d",&a,&b);
	if(a+b>100)t=(a+b)/100;
	else t=a+b;
	printf("%d\n",t);
}