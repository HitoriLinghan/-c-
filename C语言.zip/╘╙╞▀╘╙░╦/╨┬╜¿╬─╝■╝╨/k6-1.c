#include <stdio.h>
#include <math.h>
main()
{
 int a,b,c,f=1;
 double p,s;
 scanf("%d%d%d",&a,&b,&c);
 if(a+b>c||a+c>b||b+c>a)
   {
       p=(a+b+c)/2.0;
       s=sqrt(p*(p-a)*(p-b)*(p-c));
   }
   else
       f=0;
   if(f)
   printf("%f\n",s);
   else
   printf("error\n");
}