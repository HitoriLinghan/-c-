#include <stdio.h>

main() {
	int x, y;
	printf("����x:");
	scanf("%d", &x);
	if (x < 0) {
		y = x;
		printf("x=%d,y=x=%d\n", x, y);

	} else if (x < 10) {
		y = 2 * x - 1;
		printf("x=%d,y=2*x-1=%d\n", x, y);

	} else {
		y = 3 * x - 11;
		printf("x=%d,y=3*x-11=%d\n", x, y);
	}
}