#include<stdio.h>
main()
{
	char c;
    int i;
	c=getchar();
	if(c>='0'&&c<='9')
		printf("%d\n",i=c-'0');
		else i=-1;
		printf("%d\n",i);
}