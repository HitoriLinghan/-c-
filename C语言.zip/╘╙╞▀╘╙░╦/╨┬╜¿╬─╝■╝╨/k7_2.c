#include<stdio.h>
main()
{
	int x,y;
	scanf("%d",&x);
	if(x<0)y=x;
	else if(x>=0&&x<10)y=2*x-1;
	else y=3*x-11;
	printf("%d\n",y);
}