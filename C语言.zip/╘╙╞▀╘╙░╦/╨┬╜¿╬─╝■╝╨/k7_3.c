#include<stdio.h>
main()
{
	double cj;
	char g;
	scanf("%lf",&cj);
	if(cj>=95)g='A';
	else if(cj>=85)g='B';
	else if(cj>=70)g='C';
	else if(cj>=60)g='D';
	else g='E';
	printf("%c\n",g);
}