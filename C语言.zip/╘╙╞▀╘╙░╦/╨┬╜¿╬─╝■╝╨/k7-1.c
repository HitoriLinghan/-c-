#include <stdio.h>

main() {
	int a, b, c;
	scanf("%d%d", &a, &b);
	c = a + b;
	if (c > 100)
		printf("%d", c / 100);
	else
		printf("d", c);
}