#include<stdio.h>
main()
{
	int a=10,b=20,c=30,t;
	t=a;a=c;c=b;b=t;
	printf("%d,%d,%d\n",a,b,c);
}
	