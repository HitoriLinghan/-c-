#include<stdio.h>
main()
{
	int m,a,b,c;
	scanf("%d",&m);
	a=m%10;
	b=m/10%10;
	c=m/100;
	m=a*100+b*10+c;
	printf("%d\n",m);
}