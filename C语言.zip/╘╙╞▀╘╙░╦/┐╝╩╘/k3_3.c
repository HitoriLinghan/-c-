#include<stdio.h>
main()
{
	char c='c';
	printf("%c,%c\n",c-'a'+'A'-1,c+1);
}