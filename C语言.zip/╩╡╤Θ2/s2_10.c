#include<stdio.h>
main()
{
	double F,c;
	printf("input:");
	scanf("%lf",&F);
	c=(F-32)/9*5;
	printf("%.2f=%.2f\n",F,c);
}
