#include<stdio.h>
main()
{
	int x,y,n;
	printf("Input x,y:");
	scanf("%d%d",&x,&y);
	n=x+y;
	y=n-y;
	x=n-x;
	printf("x=%d,y=%d\n",x,y);
}