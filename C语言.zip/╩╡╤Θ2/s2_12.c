#include<stdio.h>
main()
{
	double x;
	printf("input x:");
	scanf("%lf",&x);
	x=(int)(x*10+0.5)/10.0;
	printf("x=%.1f\n",x);
}