/*****s2_2.c*****/
#include<stdio.h>
main()
{
	int a,b,d=241;
	a=d/100%9;
	b=(-1)&&(-1);
	printf("%d,%d\n",a,b);
}
