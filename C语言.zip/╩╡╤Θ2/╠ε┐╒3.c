/*****s2_3.c*****/
#include<stdio.h>
main()
{
	int a=3,b=2,c=1,d;
	d=(a>b>c);
	printf("%d\n",d);
}