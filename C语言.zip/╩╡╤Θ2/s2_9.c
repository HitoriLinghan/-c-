#include<stdio.h>
main()
{
int a,b,c,max;
printf("Input:");
scanf("%d%d%d",&a,&b,&c);
max=a>b?a:b;
max=max>c?max:c;
printf("%d\n",max);
}