#include<stdio.h>
main()
{
	double x,y;
	printf("input:");
	scanf("%lf%lf",&x,&y);
	printf("x+y=%.2f,x-y=%.2f,x*y=%.2f,x-y=%.2f\n",x+y,x-y,x*y,x/y);
}