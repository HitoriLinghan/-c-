#include<stdio.h>
main()
{
	char c;
	printf("Input a character:");
	c=getchar();
	printf("%c,%d\n",c,c);
}