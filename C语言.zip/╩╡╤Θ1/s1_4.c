#include <stdio.h>
main()
{
    int a,b,c,d;
    a=100;
    b=30;
    c=a/b;
    d=a%b;
	printf("a=%d,b=%d,c=%d,d=%d\n",a,b,c,d);
}