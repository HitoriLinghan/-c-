#include <stdio.h>
main()
{
    int a,b,c;
    a=020;
    b=0x20;
    c=20;
    printf("a=%d,b=%d,c=%d \n",a,b,c);
}