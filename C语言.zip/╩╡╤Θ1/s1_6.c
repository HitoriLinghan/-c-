#include <stdio.h>
main()
{
	float r,s;
	r=2;
	s=3.14159*r*r;
	printf("area=%f\n",s);
}