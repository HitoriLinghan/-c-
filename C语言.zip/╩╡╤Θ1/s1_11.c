#include <stdio.h>
main()
{
	int n=1050;
	int h,m;
	h=n/60;
	m=n%60;
	printf("%dСʱ%d����\n",h,m);
}