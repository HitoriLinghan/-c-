#include <stdio.h>
main()
{
    int a,b,c,v;
    a=3;
    b=4;
    c=5;
    v=a*b*c;
printf(" v=%d\n",v);
}