#include <stdio.h>
main()
{
	int i,j,m,n;
    i=8;
	j=10;
	m=++i;
	n=j++;
	printf("%d,%d,%d,%d\n",i,j,m,n);
}