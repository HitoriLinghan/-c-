#include <stdio.h>

int main() {
    int n, x, y, z;
    printf("Input n(n<1000):");
    scanf("%d", &n);

    if (n < 200 || n > 999) {
        printf("invalid");
        return 0;
    }

    for (x = 1; x <= 9; x++) {
        for (y = 0; y <= 9; y++) {
            for (z = 0; z <= 9; z++) {
                if (x * 100 + y * 10 + z + y * 100 + z * 10 + z == n) {
                    printf("X=%d,Y=%d,Z=%d", x, y, z);
                    return 0;
                }
            }
        }
    }

    printf("invalid");
    return 0;
}
