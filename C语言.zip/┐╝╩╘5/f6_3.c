#include <stdio.h>

int main() {
    int i;
    double score, min = 100;

    for (i = 0; i < 10; i++) {
        scanf("%lf", &score);

        if (score < min) {
            min = score;
        }
    }

    printf("%f", min);
    return 0;
}
