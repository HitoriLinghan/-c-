#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int i, num;
    int negative = 0, zero = 0, positive = 0; // �ֱ��¼��������������ĸ���

    for (i = 1; i <= n; i++) {
        scanf("%d", &num);
        if (num < 0) {
            negative++;
        } else if (num == 0) {
            zero++;
        } else {
            positive++;
        }
    }

    printf("%d,%d,%d\n",negative,zero,positive);
    return 0;
}
