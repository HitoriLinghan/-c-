#include <stdio.h>

unsigned int gcd(unsigned int a, unsigned int b) {
    return b == 0 ? a : gcd(b, a % b);
}

unsigned int lcm(unsigned int a, unsigned int b) {
    return (a * b) / gcd(a, b);
}

int main() {
    unsigned int u, v;
    
    do {
        scanf("%u %u", &u, &v);
    } while (u <= 0 || v <= 0);
    
    printf("��Լ��%u\n", gcd(u, v));
    printf("������%u\n", lcm(u, v));
    
    return 0;
}