#include <stdio.h>

int isPrime(int num) {
    int i;
    if (num == 2 || num == 3) return 1;
    if (num == 1 || num % 2 == 0) return 0;
    for (i = 3; i * i <= num; i += 2) {
        if (num % i == 0) return 0;
    }
    return 1;
}

int main() {
    int n, i, j;
    scanf("%d", &n);
    for (i = 2; i <= n - 2; i++) {
        if (isPrime(i) && isPrime(n - i)) {
            printf("%d=%d+%d\n", n, i, n - i);
        }
    }
    return 0;
}