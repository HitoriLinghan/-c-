#include <stdio.h>
#include <math.h>

int main() {
    int c, count = 0;
    scanf("%d", &c);
    for (int a = 1; a <= c; a++) {
        for (int b = a; b <= c; b++) {
            int temp = a * a + b * b;
            if (temp == c * c) {
                printf("%d,%d,%d\n", a, b, c);
                count++;
            }
        }
    }
    printf("%d", count);
    return 0;
}
