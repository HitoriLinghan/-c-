#include <stdio.h>

int main() {
    int n, temp;
    scanf("%d", &n);

    int sum = 0;
    while (n != 0) { // ѭ��ȡ��ÿһλ���ֲ��ۼ�
        temp = n % 10;
        sum += temp;
        n /= 10;
    }

    printf("%d\n", sum);
    return 0;
}