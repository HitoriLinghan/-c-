#include <stdio.h>
main()
{
    int n=0,t;
    for(t=0;t<=20*7;t++)
    {
        if (t%5==0&&t<=20*5)n++;
        else if(t%6==0&&t<=20*6)n++;
        else if(t%7==0)n++;
    }
    printf("n=%d\n", n);
}
