#include<stdio.h>
int main()
{
   char c1,c2,c3,max,mid,min;
   c1=getchar();
   c2=getchar();
   c3=getchar();
   max=c1>c2?c1:c2;
   max=max>c3?max:c3;
   min=c1<c2?c1:c2;
   min=min<c3?min:c3;
   mid=(c1+c2+c3)-(max+min);
   printf("%c%c%c\n",min,mid,max);
   return 0;
}