#include<stdio.h>
main()
{
	int a,b,c;
	scanf("%d,%d,%d",&a,&b,&c);
	a=a/3;b=b+a;c=c+a;
	b=b/3;a=a+b;c=c+b;
	c=c/3;a=a+c;b=b+c;
	printf("%d,%d,%d\n",a,b,c);
}