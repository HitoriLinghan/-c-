#include<stdio.h>
int main()
{
	char a,b;
	a=getchar();
	b=getchar();
	putchar(a+1);
	putchar('\n');
	putchar(b-'a'+'A');
	putchar('\n');
	return 0;
}