#include <stdio.h>
int main()
{
    int x,y;
    scanf("%d",&x);
    if (x==0)
    {
        y=++x,x=--x;
    }    
    else 
    {
        y=--x,x=++x;
    }
    printf("x=%d,y=%d",x,y);
    return 0;
}