#include <stdio.h>

int main()
{
    int x;
    char c;  
    scanf("%d", &x);
    if (x>0&&x<60) 
    {
        printf("x=%d,%c\n",x,c='A');
    }
    else if (x==60)
    {
        printf("x=%d,%c\n",x,c='B');
    }
    else if (x > 60 && x <= 85)
    {
        printf("x=%d,%c\n",x,c='C');
    }
    else if (x>85&&x<=100)
    {
        printf("x=%d,%c\n",x,c='D');
    }
    else
    {
        printf("err.\n");
    } 
    return 0;
}