#include<stdio.h>
#include<string.h>
int main()
{
    char a[20]="Good\t\\\0China";
    int i,j;
    i=sizeof(a);
    j=sizeof(a);
    printf("%d,%d\n",i,j);
}