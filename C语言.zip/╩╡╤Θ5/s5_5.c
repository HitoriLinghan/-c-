#include<stdio.h>
int main()
{
	int i;
	char s1[20],s2[20];
	printf("enter string1:");
	gets(s1);
	for (i=0;i<=20;i++)
		s2[i]=s1[i];
	printf("string2:%s\n",s2[i]);
}