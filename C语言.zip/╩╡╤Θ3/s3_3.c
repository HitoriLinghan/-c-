#include <stdio.h>
int main()
{
    int x=1,y=0;
    switch(x)
    {
        case 1:
        switch(y)
    {
        case 0:printf("first\n");break;
        case 1:printf("second\n");break;
    }
        case2:printf("third\n");
    }
    return 0;
}