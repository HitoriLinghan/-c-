#include<stdio.h>
main()
{
  int x,y;
  printf("Input x: ");
  scanf("%d",&x);
  if(x>-5&&x<10)
  {if(x>-5&&x<0)y=x-1;
  if(x==0)y=x;
  if(x>0&&x<10)y=x+1;
  printf("y=%d\n",y);}
  else printf("x�������\n");
}