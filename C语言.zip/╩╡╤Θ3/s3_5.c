#include <stdio.h>
int main()
{
    int a,b,c,d,t;
    printf("input 4 numbers:\n");
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if (a<b) {t=a;a=b;b=t;};
    if () {t=a;a=c;c=t;};
}