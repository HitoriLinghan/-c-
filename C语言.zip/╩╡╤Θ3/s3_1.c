#include <stdio.h>
int main()
{
    int a=10;
    if (a>10) printf("%d\n",a>10);
      else printf("%d\n",a<=10);
    return 0;
}