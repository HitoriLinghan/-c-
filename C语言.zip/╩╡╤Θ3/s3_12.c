#include<stdio.h>
main()
{
  int x;
  char c;
  printf("����ѧ���ɼ�:");
  scanf("%d",&x);
  switch((int)(x/10))
  {case 10:
  case 9:c='A';break;
  case 8:c='B';break;
  case 7:c='C';break;
  case 6:c='D';break;
  default :c='E';
  }
  printf("�ȼ�%c\n",c);
}