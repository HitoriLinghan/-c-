#include<stdio.h>
main()
{
	int past,fly,x,now;
	scanf("%d %d",&past,&fly);
	x=(past/100)*60+past%100;
	now=(x+fly)/60*100+(x+fly)%60;
	printf("%d,%d\n",past,now);
}