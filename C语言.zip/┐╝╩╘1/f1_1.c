#include<stdio.h>
main()
{
	int m,f,i;
	double t;
	scanf("%d",&m);
	t=m/100.0/0.3048;
	f=t;
	i=(t-f)*12;
	printf("input:%d,foot:%d,inch:%d\n",m,f,i);
}