#include<stdio.h>
main()
{
	int a=1,b=2,c=3,d=4,t;
	t=a;a=d;d=b;b=c;c=t;
	printf("a=%d,b=%d,c=%d,d=%d\n",a,b,c,d);
}
	