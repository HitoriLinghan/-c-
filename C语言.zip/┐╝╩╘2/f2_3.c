#include <stdio.h>
main()
{
    double a,b,c,d,t,max;
    scanf("%lf %lf %lf",&a,&b,&c);
    t=a>b?(a>c?a:c):(b>c?b:c)*10;
    d=(int)t;
    max=d/10.0;
    printf("%.6lf\n",max);
}