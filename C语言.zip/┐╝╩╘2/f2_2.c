#include <stdio.h>
int main()
{
    int a,b;
    printf("input1-7:");
    scanf("%d",&a);
    b=(a+20)%7;
    if (a>1) printf("20day later is:%d\n",b);
      else printf("20day later is:7\n");
    return 0;
}