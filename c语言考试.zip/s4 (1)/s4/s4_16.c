#include<stdio.h>
main()
{int i=1;
double s=1,e=1;
while(1)
{s=s*i;
if(1/s<1e-6)break;
e=e+1/s;
i++;
}
printf("%f\n",e);
}