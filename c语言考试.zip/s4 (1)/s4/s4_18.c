#include<stdio.h>
main()
{
	int u,v,t;
	scanf("%d%d",&u,&v);
	if(u<v){t=u;u=v;v=t;}
	while(v)
	{t=u%v;
	u=v;
	v=t;}
	printf("%d\n",u);
}