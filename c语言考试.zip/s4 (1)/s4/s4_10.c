#include<stdio.h>
main()
{
	int i=1,s=0,f=1;
	while(i<=101)
	{s=s+i*f;
	i=i+2;
	f=-f;
	}
	printf("%d\n",s);
}