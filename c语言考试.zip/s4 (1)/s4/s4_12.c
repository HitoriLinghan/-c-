#include<stdio.h>
main()
{
	int n,i=1;
	double s=1;
	scanf("%d",&n);
	while(i<=n)
	{s=s*i;
	i++;
	}
	printf("%f\n",s);
}