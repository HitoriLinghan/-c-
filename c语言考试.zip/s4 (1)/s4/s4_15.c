#include<stdio.h>
main()
{
	int x,y;
	for(x=1;x<30;x++)
		if(x*2+(30-x)*4==90)printf("��%d,��%d\n",x,30-x);
}