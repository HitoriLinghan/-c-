#include<stdio.h>
main()
{int i=200,a,b,c;
while(i<=300)
{a=i/100;
b=i/10%10;
c=i%10;
if(a*b*c==42&&a+b+c==12)printf("%d,",i);
i++;
}
}