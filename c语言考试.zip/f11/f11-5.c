#include <stdio.h>
#include <stdlib.h>
int mid(int a,int b,int c);
main()
{
    int a, b, c ,m;
    scanf("%d%d%d",&a,&b,&c);
    m=mid(a,b,c);
    printf("The result:%d\n",m);
}
int mid(int a,int b,int c)
{
   int t;
   if(a>b&&a<c||a<b&&a>c)t=a;
   if(b>a&&b<c||b>c&&b<a)t=b;
   if(c>a&&c<b||c>b&&c<a)t=c;
   return t;
}

 

