//输出格式"%d->%d"
#include<stdio.h>
int i=0;
void hanoi(int n, int a, int b, int c);
main( )
 { int n;
  printf("input n:"); 
  scanf("%d",&n);
  hanoi(n, 1, 2, 3); 
  printf("Total number:%d\n",i);
}

void hanoi(int n, int a, int b, int c)
{  
	 if(n==1) {
	 printf("%d->%d->%d\n",n,a,c);i++;}
	 else 
	 {
	 	hanoi(n-1,a,c,b);i++;
	 	printf("%d->%d->%d\n",n,a,c);
	 	hanoi(n-1,b,a,c);
	  } 
}
