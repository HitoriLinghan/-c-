#include <stdio.h>
#include <stdlib.h>
int legal(int y);//判断输入年份的合法性
void leapyear(int y);//判断是否闰年
int judgeweeknumber(int y);//计算元旦是星期几
void judgeweekchinese(int y);//输出文字形式的星期几

main()
{   
 int number,week,year,f=1;
 while(f)
 { system("cls");//清屏
   printf("请输入年份:\n");
   scanf("%d",&year);
   printf("\n功能菜单:\n");
   printf("1.闰年信息查询\n2.元旦是星期几查询\n3.程序结束\n");
   printf("请选择功能:\n");
   scanf("%d",&number);
   if(number==1)
   {   year=legal(year);
       leapyear(year);
        } 
   if(number==2)
   {   printf("\n");
	   week=judgeweeknumber(year);
       judgeweekchinese(week);
   }
   if(number==3)
         f=0;
   printf("\nEnter any key to continue\n");
   getchar();
   getchar();
   }
} 

int legal(int y)
{ 
   if(y<0)
   do {
     printf("Please re-enter a year:");
     scanf("%d",&y);
     } while(y<0);
   return y;
}

void leapyear(int y)
{  
	if((y%100!=0&&y%4==0)||y%400==0) printf("%d是闰年\n",y);
	else printf("%d不是闰年\n",y);
}

int judgeweeknumber(int y)
{   
	int w;
	w=(y+(y-1)/4-(y-1)/100+(y-1)/400)%7;
	return w;
}

void judgeweekchinese(int week)
{   
	switch(week)
	{
		case 0:{printf("元旦是星期天");break;}
		case 1:{printf("元旦是星期一");break;}
		case 2:{printf("元旦是星期二");break;}
		case 3:{printf("元旦是星期三");break;}
		case 4:{printf("元旦是星期四");break;}
		case 5:{printf("元旦是星期五");break;}
		case 6:{printf("元旦是星期六");break;}
	}
}