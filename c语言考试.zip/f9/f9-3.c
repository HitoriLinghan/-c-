#include<stdio.h>
#include<string.h>//在使用字符串处理函数时，应当在程序文件的开头加入此头文件
int main()
{
 int n,i,j=1;
 char a[50];
 while(scanf("%d",&n)!=EOF)
 {
  getchar();//把第一个输入的字符n吸收掉
  while(n--)
  {
   gets(a);
   if(!(a[0]=='_'||(a[0]>='a'&&a[0]<='z')||(a[0]>='A'&&a[0]<='Z')))//gets()存储字符串到数组时，是从a[0]开始储存的，先判断第一个字符是否是合法字符
          printf("no\n");
   else
   {
     for(i=1;a[i]!='\0';i++)//判断完第一个字符后，从啊[1]开始往后逐一判断各个字符是否是合法字符，直到'\0'结束，用gets()存储字符串时会自动在末尾加上'\0'
     {
       if(!(a[i]=='_'||(a[i]>='0'&&a[i]<='9')||(a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')))
       {
         printf("no\n");
         break;
       }
     }
     if(i==strlen(a))//如果i的值等于这个字符串的长度，则表明这个字符串的字符都是合法标识符
    {
     printf("yes\n");
    }
   }
  }
 }
 return 0;
}