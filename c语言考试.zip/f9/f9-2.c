#include<stdio.h>

int main()
{char s[100],c;
int i,n=0;
printf("请输入字符串\n");
gets(s);
printf("请输入字符\n");
c=getchar();
for(i=0;s[i];i++)
{
	if(s[i]!=c)s[n++]=s[i];
 s[n]=0;

puts(s);

}}