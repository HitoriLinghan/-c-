#include<stdio.h>
#include<string.h>
char str1[100],str2[300];
void func()
{int i,j=0;
for(i=0;str1[i];i++)
str2[j++]=str2[j++]=str2[j++]=str1[i];

}
void main()
{
  gets(str1);
   func();
  printf("%s\n",str2);
}
