#include<stdio.h>
#include<string.h>

void change(char s1[],char s2[])
{int i,j=0,l;
l=strlen(s1);
for(i=l;i>=0;i--)
s2[j++]=s2[j++]=s1[i-1];
}
 main()
{
  char s1[20],s2[20];
  gets(s1);
  change(s1,s2);
  puts(s2);
}
