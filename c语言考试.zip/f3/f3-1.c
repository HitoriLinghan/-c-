#include<stdio.h>
int main()
{ int a,b;
char c,d;
double x,y;
scanf("%2d %2d %c %c %lfy=%lf",&a,&b,&c,&d,&x,&y);
printf("a=%d,b=%d,c=%c,d=%c,x=%f,y=%f\n",a,b,c,d,x,y);


 	return 0;
}
