#include<stdio.h>
int main()
{char a,b,c,x,y,z;
scanf("%c%c%c",&a,&b,&c);
x=a>b?a:b;
x=x>c?x:c;
y=a<b?a:b;
y=y<c?y:c;
z=a+b+c-x-y;
printf("%c%c%c\n",y,z,x);
 	return 0;
}
