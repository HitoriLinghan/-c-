#include<stdio.h>
#include<math.h>
int isprime (int m)
{
    int i,k;
    k = sqrt(m);
    for(i = 2;i <= k;i++)
    {
        if(m % i == 0)
        {
            return 0;
            break;
        }
    }
   return 1;
}
int main(void)
{
    int a,i;
    printf("请输入一个偶数：");
    scanf("%d",&a);
    for(i = 2;i <= a; i++)
    {
        if(isprime(i) && isprime(a-i))
            printf("%d=%d+%d\n",a,i,a-i);
    }
    return 0;
}