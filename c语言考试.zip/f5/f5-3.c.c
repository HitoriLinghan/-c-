#include<stdio.h>
int main()
{
	int a=0,b=0,c=0,i=0;
	while(a<=5*20||b<=6*20||c<=7*20)
    {if(a%5==0||b%6==0||c%7==0)
    i++;
    if(a<=5*20)
    a++;
    if(b<=6*20)
    b++;
    if(c<=7*20)
    c++;
	}
	printf("n=%d",i);
 	return 0;
}
