#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main ()
{
    int n,z=1;
    scanf("%d",&n);
    for(int i=2;i<n;i++)
    {
        if(n%i==0)
        {
            z=0;
        }
    }
            if(n==0||n==1)
        {
            z=0;
        }
    if(z==1)
    {
        printf("Yes");
    }
   else
    {
        printf("No");
    }

}
