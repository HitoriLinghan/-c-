#include<stdio.h>
int main()
{

	int n,i=1;
	double s=1,e=0;
	scanf("%d",&n);
	while(i<=n)
	{
		s=s*i;
		e=e+s/100;
		i++;
	}
	printf("%f\n",e);

 	return 0;
}
