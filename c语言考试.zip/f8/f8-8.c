#include<stdio.h>
#define N 100
int main()
{
char a[N],b[N],n[2*N],t;
int i,j,k,m;
scanf("%s%s",a,b);
for(i=0;a[i]!=0;i++)
n[i]=a[i];
for(j=0;b[j]!=0;j++,i++)
n[i]=b[j];
n[i]='\0';
for(k=0;k<i;k++){
	for(m=k+1;m<i;m++)
	if(n[k]>n[m]){
		t=n[k];
		n[k]=n[m];
		n[m]=t;
	}
}
puts(n);
 	return 0;
}
