#include<stdio.h>
int main()
{
	char s[101];
	int i,j,k;
	gets(s);
	for(i=0;s[i];i++){
		for(j=k=i+1;s[j];j++)
		if(s[j]!=s[i])
		s[k++]=s[j];
		s[k]='\0';
	}
	printf("%s\n",s);


 	return 0;
}
