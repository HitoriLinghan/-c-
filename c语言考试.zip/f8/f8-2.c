#include<stdio.h>
main()
{int m,n=0,a[100],i=0;
scanf("%d",&m);
while(m)
{
	a[i++]=m%8;
	m=m/8;
}
for(i--;i>=0;i--)printf("%d",a[i]);
printf("\n");
}