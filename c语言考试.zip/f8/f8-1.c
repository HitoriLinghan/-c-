#include<stdio.h>
main()
{
	int a[10],i,max,min;
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	max=min=0;
	for(i=0;i<10;i++)
	{
		if(a[i]>a[max])max=i;
		else if(a[i]<a[min])min=i;
	}
	printf("���ֵ%d��%dλ\n",a[max],max+1);
    printf("��Сֵ%d��%dλ\n",a[min],min+1);
}