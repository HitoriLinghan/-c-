#include<stdio.h>
int main()
{
	int a[50],b[6]={0},c[6];
	int n,i,j,s=0;
	printf("输入职工数n<=50:\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{scanf("%d",&a[i]);
	s+=a[i];
	c[0]=a[i]/100;
	c[1]=(a[i]-c[0]*100)/50;
	c[2]=(a[i]-c[0]*100-c[1]*50)/20;
	c[3]=(a[i]-c[0]*100-c[1]*50-c[2]*20)/10;
	c[4]=(a[i]-c[0]*100-c[1]*50-c[2]*20-c[3]*10)/5;
	c[5]=(a[i]-c[0]*100-c[1]*50-c[2]*20-c[3]*10-c[4]*5);
	for(j=0;j<6;j++)b[j]+=c[j];
	}
    printf(" 壹佰元 伍拾元 贰拾元 拾元 伍元 壹元\n");
    for(j=0;j<6;j++)printf("%7d",b[j]);
    printf("\n");

 	return 0;
}
