#include <stdio.h>
main(){
unsigned char a[3][100000];
int i,j,k=0;
for(i=0;i<3;i++)
gets(a[i]);
for(i=0;i<3;i++)
for(j=0;a[i][j];j++)
if(a[i][j]>127){
j++;k++;};
printf("汉字出现的次数为%d\n",k);	
}
