#include<stdio.h>
int main()
{
int a[5][6],i,j,max=0,m=0,t=0;
for(i=0;i<5;i++)
for(j=0;j<6;j++)
scanf("%d",&a[i][j]);
for(i=0;i<5;i++)
for(j=0;j<6;j++)
if(abs(a[i][j])>abs(a[m][t]))
{max=a[i][j];m=i;t=j;}
printf("max:%d\n",a[m][t]);
printf("row:%d,col:%d\n",m,t);
 	return 0;
}
