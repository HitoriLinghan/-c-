#include <stdio.h>
main()
{
int a[4][3],b[4][3],c[4][3],i,j,k=0;
printf("请输入a矩阵\n");
for(i=0;i<4;i++)
for(j=0;j<3;j++)
scanf("%d",&a[i][j]);
printf("请输入b矩阵\n");
	for(i=0;i<4;i++)
for(j=0;j<3;j++)
scanf("%d",&b[i][j]);
printf("输出c矩阵\n");
for(i=0;i<4;i++)
for(j=0;j<3;j++)
c[i][j]=a[i][j]+b[i][j];
for(i=0;i<4;i++)
for(j=0;j<3;j++){
printf("%6d",c[i][j]);k++;
if(k%3==0)printf("\n");};
}
