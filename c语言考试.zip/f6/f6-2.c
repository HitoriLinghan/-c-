#include<stdio.h>
main()
{
	int x,n,a1,a2,a3,i;
	a1=a2=a3=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{scanf("%d",&x);
	if(x>0) a1++;
else	if(x==0) a2++;
   else if(x<0) a3++;
	}
	printf("%d,%d,%d\n",a1,a2,a3);}