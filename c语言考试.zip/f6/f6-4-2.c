#include <stdio.h>
main()
{
int i;
double s=0,a=81;
for(i=1;i<=25;i++){
s=s+a;
a=sqrt(a);
if(s>=110)break;
}
printf("%d\n",i-1);
 } 
