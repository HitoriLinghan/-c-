#include<stdio.h>
int main()
{int X,Y,Z,n,a;
printf("Input n(n<1000):\n");
scanf("%d",&n);
for(X=1;X<10;X++)
{for(Y=0;Y<10;Y++)
{for(Z=0;Z<10;Z++)
{if(X*100+Y*10+Z+Y*100+Z*10+Z==n)
{
a=0;
printf("X=%d,Y=%d,Z=%d",X,Y,Z);}
	
	
}	
}


}
if(a)printf("Invalid");
 	return 0;
}
