#include<stdio.h>
#include<math.h>
int main()
{int h,w,i;
char c;

while(1)
{
printf("输入体重:");
scanf("%d",&w);
printf("输入身高:");
scanf("%d",&h);	
if(abs(w-(h-100)*0.9*2)<(h-100)*0.9*0.2){printf("完美身材\n");}
else if((w-(h-100)*0.9*2)>=abs((h-100)*0.9*0.2)){printf("太胖了\n");}
else if(((h-100)*0.9*2-w)>=abs((h-100)*0.9*0.2)){printf("太瘦了\n");}

printf("还要输入吗 Y/N:");
if(getchar()=='y'){
continue;}
if(getchar()=='n')
{
  break;}}
 	return 0;
}
