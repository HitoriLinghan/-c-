#include<stdio.h>
main()
{
float score,max,min,s=0;
int i;
printf("请输入10个评委给张三的评分：\n");
scanf("%f",&score);
max=min=score;
s+=score;
for(i=2;i<=10;i++)
{

scanf("%f",&score);
if(max<score)
max=score;
if(min>score)
min=score;
s=s+score;
}
s=(s-max-min)/8;

printf("张三得分: %f\n",s);
}