#include<stdio.h>
int main()
{
int x,y;
scanf("%d",&x);
if(x>65&&x<=100)y=1;
else if(x==65)y=2;
else if(x>=0&&x<65)y=3;
switch(y)
{
case 1: printf("x=%d,A\n",x);break;
case 2 :printf("x=%d,B\n",x);break;
case 3 :printf("x=%d,C\n",x);break;
default: printf("err.\n");}
 	return 0;
}
