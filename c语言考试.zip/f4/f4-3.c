#include<stdio.h>
int main()
{
int x;
scanf("%d",&x);
if(x>85&&x<=100)printf("x=%d,D\n",x);
else if(x>60&&x<=85)printf("x=%d,C\n",x);
else if(x==60)printf("x=%d,B\n",x);
else if(x>0&&x<60)printf("x=%d,A\n",x);
else printf("err.\n");
 	return 0;
}
