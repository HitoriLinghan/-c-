#include<stdio.h>
main()
{
	int x,y,t1,t2;
	scanf("%d",&x);
	t1=t2=x;
	y=++t1;
	if(x)y=--t2;
	printf("x=%d,y=%d\n",x,y);
}
