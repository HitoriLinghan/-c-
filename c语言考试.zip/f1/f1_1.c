#include<stdio.h>
int main()
{
int a=010;
printf("a=%d\n",a);

 	return 0;
}
