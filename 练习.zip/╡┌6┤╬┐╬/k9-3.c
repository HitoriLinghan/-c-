#include<stdio.h>
main()
{
	int x=1000,a,b,c,d;
	while(x>=1000&&x<=9999)
	{a=x/1000;
	b=x%1000/100;
	c=x/10%10;
	d=x%10;
	if(b==2&&x%23==0&&d==3) printf("%d,",x);
	x++;}
	printf("\n");
}
