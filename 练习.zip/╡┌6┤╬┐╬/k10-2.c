#include<stdio.h>
main()
{
	char c;
	int a1,a2,a3,a4;
	a1=a2=a3=a4=0;
	while((c=getchar())!='\n')
	{if(c>='A'&&c<='Z'||c>='a'&&c<='z') a1++;
	else if(c==' ') a2++;
	else if(c>='0'&&c<='9') a3++;
	else a4++;}
printf("Ӣ����ĸ%d\n",a1);
printf("�ո�%d\n",a2);
printf("����%d\n",a3);
printf("�����ַ�%d\n",a4);
}