#include<stdio.h>
main()
{
  int f1,f2,f3,i,s=2;
  f1=f2=1;
  for(i=3;i<=20;i++)
  {f3=f1+f2;
  s=s+f3;
  f1=f2;
  f2=f3;}
  printf("%d\n",s);
}
