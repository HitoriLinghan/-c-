#include<stdio.h>
main()
{
	int x=0,y=90;
	while(x<=30)
	{if(2*x+(30-x)*4==90) printf("��%d,��%d\n",x,30-x);
	x++;}
}

	