#include<stdio.h>
main()
{
	char c;
	int i=0;
	while((c=getchar())!='\n')
	{if(c>='0'&&c<='9') i=i*10+(c-'0');}
	printf("%d\n",i);
}
