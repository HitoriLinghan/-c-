#include<stdio.h>
main()
{
	int i,j,k;
	for(i=1;i<=9;i++)
	{for(k=1;k<=35-4*i;k++) printf(" ");
	for(j=1;j<=i;j++)
	printf("%2d*%2d=%2d",j,i,j*i);
	printf("\n");}
}