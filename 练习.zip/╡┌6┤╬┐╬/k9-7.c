#include<stdio.h>
main()
{
	int a,b,t=0;
	for(a=2;a<=100;a++)
	{for(b=2;b<a;b++)
	if(a%b==0)break;   
	if(b>=a) 
	{t++;
    printf("%d,",a);
	if(t%6==0)printf("\n");}
	}
	printf("\n");
	
	
}