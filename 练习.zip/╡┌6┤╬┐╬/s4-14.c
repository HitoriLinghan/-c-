#include<stdio.h>
main()
{
	int x=200,a,b,c;
	while(x>=200&&x<=300)
	{a=x/100;
	b=x/10%10;
	c=x%10;
	if (a+b+c==12&&a*b*c==42) printf("%d,",x);
    x++;
	}
printf("\n");
}
