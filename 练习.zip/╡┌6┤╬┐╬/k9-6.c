#include<stdio.h>
main()
{
	int x,y,s;
	for(x=1;x<=1000;x++)
	{for(y=1,s=0;y<x;y++)
	if(x%y==0) s=s+y;
	if(s==x) printf("%d,",x);}
printf("\n");
	}