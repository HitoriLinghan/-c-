#include<stdio.h>
main()
{
	unsigned u,v,temp,t;
	scanf("%d%d",&u,&v);
	if(u<v){t=v;v=u;u=t;}
	while(v!=0)
	{temp=u%v;
	 u=v;
	 v=temp;}
	printf("%d\n",u);
}
