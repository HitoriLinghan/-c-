#include<stdio.h>
main()
{
	int a=2,b=8;
	a=a-b;
	b=a+b;
	a=b-a;
printf("%d,%d\n",a,b);
}
