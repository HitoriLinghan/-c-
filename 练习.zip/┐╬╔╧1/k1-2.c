#include<stdio.h>
main()
{
	double x;
	int y;
	x=-8.6;
	y=-3;
	printf("%.1f+%d=%.1f\n",x,y,x+y);
    printf("%.1f-%d=%.1f\n",x,y,x-y);
    printf("%.1f*%d=%f\n",x,y,x*y);
    printf("%.1f/%d=%f\n",x,y,x/y);
    printf("%.1f%%%d=%d\n",x,y,(int)x%y);
}

	
