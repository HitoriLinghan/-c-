#include<stdio.h>
main()
{
	float x=2.5,y=8.9,z;
	z=y;
	y=x;
	x=z;
	printf("x=%f,y=%f\n",x,y);
}
