#include<stdio.h>
main()
{
	int a,b,c,max;
	int func(int a,int b,int c);
	scanf("%d%d%d",&a,&b,&c);
	max=func(a,b,c);
	printf("%d\n",max);
}

int func(int a,int b,int c)
{
	int max;
	max=a;
	if(max<b)max=b;
	if(max<c)max=c;
	return max;
}