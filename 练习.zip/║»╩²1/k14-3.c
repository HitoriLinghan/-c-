#include<stdio.h>
main()
{void sortpx(double x[]);
	double x[4];
	int i;
	for(i=0;i<4;i++)scanf("%lf",x+i);
	sortpx(x);
	for(i=0;i<4;i++)printf("%f,",x[i]);
	printf("\n");

}
void sortpx(double x[])
{
	double t;
	if(x[0]>x[1]){t=x[0];x[0]=x[1];x[1]=t;}
	if(x[0]>x[2]){t=x[0];x[0]=x[2];x[2]=t;}
	if(x[0]>x[3]){t=x[0];x[0]=x[3];x[3]=t;}
	if(x[1]>x[2]){t=x[1];x[1]=x[2];x[2]=t;}
	if(x[1]>x[3]){t=x[1];x[1]=x[3];x[3]=t;}
	if(x[2]>x[3]){t=x[2];x[2]=x[3];x[3]=t;}


}