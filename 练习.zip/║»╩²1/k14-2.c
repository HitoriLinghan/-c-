#include<stdio.h>
main()
{
	int n,i;
	double s=0;
	double func(int n);
	scanf("%d",&n);
	for(i=1;i<n;i=i+2)
		s=s+func(i);
	printf("%f\n",s);

}

double func(int n)
{
	int i;
	double a=1;
	for(i=1;i<=n;i++)
		a=a*i;
	return a;
}