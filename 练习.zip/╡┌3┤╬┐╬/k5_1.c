#include<stdio.h>
main()
{
	char c1,c2;
	c1=getchar();
	c2=getchar();
	putchar(c1-'a'+'A');
	putchar(c2-'a'+'A');
	putchar('\n');
	printf("%d,%d\n",c1,c2);
}
