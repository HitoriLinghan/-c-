#include<stdio.h>
main()
{
	int a,b,c,d;
    scanf("%d", &a);
	b=a/3600;
	c=(a-b*3600)/60;
	d=a-b*3600-c*60; 
    printf("%d��=%dСʱ%d��%d��\n",a,b,c,d);
}
