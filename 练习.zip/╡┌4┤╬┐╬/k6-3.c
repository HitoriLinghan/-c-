#include<stdio.h>
main()
{
	char ch;
	int x;
	ch=getchar();
	x=ch-'0';
	if(x>=0&&x<=9) printf("%c\n",ch);
	else printf("-1\n");
}
