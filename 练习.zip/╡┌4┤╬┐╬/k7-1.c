#include<stdio.h>
main()
{
int a,b,c;
scanf("%d%d",&a,&b);
if(a+b>100) c=a/100+b/100;
else c=a+b;
printf("%d\n",c);
}