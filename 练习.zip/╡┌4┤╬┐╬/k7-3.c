#include<stdio.h>
main()
{
	double x,y;
	char ch;
	scanf("%lf",&x);
	if(x>=95) y=1;
	else if(x>=85&&x<94) y=2;
	else if(x>=70&&x<84) y=3;
	else if(x>=60&&x<69) y=4;
	else y=5;
	switch ((int)y)
	{
	case 1:ch='A';break;
	case 2:ch='B';break;
	case 3:ch='C';break;
	case 4:ch='D';break;
	}
	if(y!=5) printf("%c\n",ch);
	else printf("E\n");
}