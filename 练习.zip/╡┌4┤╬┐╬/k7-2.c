#include<stdio.h>
main()
{
	double x,y;
	scanf("%lf",&x);
	if(x<0) y=x;
	else if(x>=0&&x<10) y=2*x-1;
    else y=3*x-11;
	printf("y=%f\n",y);
}