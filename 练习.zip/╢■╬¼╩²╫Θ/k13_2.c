#include <stdio.h>
main()
{
	double cj[4][5]={0};
	int i,j;
	for(i=0;i<3;i++)
		for(j=0;j<4;j++)
			scanf("%lf",&cj[i][j]);
	for(i=0;i<3;i++)
		for(j=0;j<4;j++)
		{ cj[i][4]=cj[i][4]+cj[i][j]/4;
		  cj[3][j]=cj[3][j]+cj[i][j]/3;
		}
		for(i=0;i<4;i++)
		{for(j=0;j<5;j++)
		printf("%lf ",cj[i][j]);
		printf("\n");
		}
}