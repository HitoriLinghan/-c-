#include<stdio.h>
main()
{
unsigned char c[3][80];
int i,j,a1,a2,a3,a4,a5,a6;
a1=a2=a3=a4=a5=a6=0;
for(i=0;i<3;i++)
gets(c[i]);
for(i=0;i<3;i++)
 for(j=0;c[i][j];j++)
if(c[i][j]>='A'&&c[i][j]<='Z')a1++;
else if(c[i][j]>='a'&&c[i][j]<='z')a2++;
else if(c[i][j]>127)j++,a3++;
else if(c[i][j]>='0'&&c[i][j]<='9')a4++;
else if(c[i][j]==' ')a5++;
else a6++;
printf("%d,%d,%d,%d,%d,%d\n",a1,a2,a3,a4,a5,a6);
}