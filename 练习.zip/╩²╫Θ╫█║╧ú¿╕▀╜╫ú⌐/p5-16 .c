#include<stdio.h>
#include<string.h>
int main()
{
	char a[100],b[100],c[100];
	int i=0,j=0,k;
	gets(a);
	gets(b);
	for(i=0,j=0,k=0;a[i]!=0&&b[j]!=0;)
	{
		if(a[i]>b[j])
		{
			c[k]=b[j];
			j++;
		}
		else
		{
			c[k]=a[i];
			i++;
		}
		k++;
	}
	if(a[i]=='\0')
	{
		for(;b[j]!=0;j++,k++)
			c[k]=b[j];
	}
	else
	{
		for(;a[i]!=0;i++,k++)
			c[k]=a[i];
	}
	c[k]='\0';
	printf("%s",c);
	printf("\n");
	return 0;
}