#include<stdio.h>
main()
{
	int i,j,k,a[11][11];
    for (i=1;i<11;i++)
	{
		a[i][i]=1;
		a[i][1]=1;
	}
    for (i=3;i<11;i++)
        for (j=2;j<=i-1;j++)
        a[i][j]=a[i-1][j-1]+a[i-1][j];
    for (i=1;i<11;i++)
	{
		for(k=1;k<=28-3*i;k++)
			printf(" ");
    for (j=1;j<=i;j++)
        printf("%6d", a[i][j]);
    printf("\n");
	}
}