#include<stdio.h>
#include<string.h>
main()
{
	char a[100];
	int i,j,m;
	scanf("%s",a);
	for(i=0;a[i]!=0;i++)
	for(j=i+1;a[j]!=0;j++)
	if(a[i]==a[j])
	{for(m=j;a[m]!=0;m++)
	{a[m]=a[m+1];}
	j--;m--;
	}
	puts(a);
	return 0;
}
