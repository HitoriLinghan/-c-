#include<stdio.h>
main()
{
	int M,n,point=0,a[999]={0},j=0,i,have=0;
	printf("����M,n��ֵ\n");
	scanf("%d,%d",&M,&n);
	for(i=0;i<M;i++)
	{
		a[i]=i+1;
	}
	i=1;
	while(have<M)
	{
			if(j==M)
			{
				j=0;
			}else if(a[j]==0)
			{
				j++;
			}else if(i==n)
			{
				printf("%d,",a[j]);
				a[j]=0;
				i=1,j++,have++;
			}else
			{
				i++;j++;
			}
	}
	printf("\n");
}