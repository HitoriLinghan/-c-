#include<stdio.h>
main()
{   void fun(int a[],int b[],int c[]);
	int a[10]={1,2,3,4,5,6,7,8},b[10]={9,8,7,6,5,4,3,2},c[10],i;
	fun(a,b,c);
	for(i=0;i<8;i++)printf("%d,",c[i]);
	printf("\n");
}

void fun(int a[],int b[],int c[])
{int i,j=0;
for(i=0;i<10;i++)
{if(a[i]>=b[i]) c[j++]=a[i];
else c[j++]=b[i]; }
}
