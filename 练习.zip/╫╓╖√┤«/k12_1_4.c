#include<stdio.h>
main()
{
	char s1[1],s2[10];
	int i,j;
	scanf("%c",&s1);
	scanf("%s",s2);
	for(i=0;s2[i];i++)
    {if(s1[0]==s2[i]) break;}
	if(s2[i]) j=i+1;
	else j=-1;
	printf("%d\n",j);
}
	