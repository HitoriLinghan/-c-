#include<stdio.h>
main()
{
	char s1[100];
	int i,j=0;
	scanf("%s",s1);
	for(i=0;s1[i];i++)
	j++;
	printf("long:%d\n",j);
}