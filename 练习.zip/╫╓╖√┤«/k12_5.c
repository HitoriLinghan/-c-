#include<stdio.h>
main()
{
	char s1[100],s2[100];
	int i,j=0;
	gets(s1);
	gets(s2);
	for(i=0;s1[i];i++)
	if(s1[i]!=s2[i]) j++;
	printf("%d\n",j);
}
