#include<stdio.h>
main()
{
	char s1[7],s2[10];
	int i,j=0;
	gets(s1);
	if(s1[0]>='1'&&s1[0]<='5') s2[j++]='8';
	else s2[j++]='5';
    for(i=0;s1[i];i++)	
    s2[j++]=s1[i];
    s2[j]=0;
	puts(s2);
}

