#include<stdio.h>
main()
{
	char s1[4],s2[8];
	int i,j=0;
	gets(s1);
	for(i=0;s1[i];i++)
	s2[j++]=s1[i];
	s2[j]=0;
    for(i=0;s1[i];i++)
	s2[j++]=s1[i];
	s2[j]=0;
    puts(s2);
}
	 
