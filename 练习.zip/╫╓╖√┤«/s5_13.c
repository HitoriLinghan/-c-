#include<stdio.h>
main()
{
	char s1[1000];
	int i;
	gets(s1);
	for(i=0;s1[i];i++)
	{if(s1[i]>='a'&&s1[i]<='z'&&i%2==0)
	s1[i]=s1[i]-'a'+'A';}
    puts(s1);
}

