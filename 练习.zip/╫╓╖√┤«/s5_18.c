#include<stdio.h>
main()
{
	char s1[100],s2[100];
	int i,j=0;
	gets(s1);
	for(i=0;s1[i];i++)
	if(s1[i]>='0'&&s1[i]<='9')
	{s2[j]=s1[i];
	j++;}
	s2[j]=0;
	puts(s2);
}