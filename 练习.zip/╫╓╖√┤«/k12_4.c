#include<stdio.h>
main()
{
	char x[100],y[10]="ABCDEFGHIJ",z[100];
	int i,j;
	gets(x);
	for(i=0;x[i];i++)
	{j=x[i]-'0';
	z[i]=y[j];}
    z[i]=0;
	puts(z);
}

