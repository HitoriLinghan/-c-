#include<stdio.h>
main()
{
	char s1[100],s2[100];
	int i,j;
	scanf("%s%s",s1,s2);
	for(i=0;s1[i]&&s2[i]&&s1[i]==s2[i];i++);
	j=s1[i]-s2[i];
	printf("%d\n",j);
}
