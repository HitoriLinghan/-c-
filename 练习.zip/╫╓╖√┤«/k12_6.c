#include<stdio.h>
main()
{
	char s[100];
	int i,n=0;
	gets(s);
	for(i=0;s[i];i++) n++;
    {for(i=0;s[i];i++)
	if(s[i]!=s[n-i-1]) {printf("no");break;}
    if(s[i]==s[n-i-1]) printf("yes");}
    printf("\n");
}