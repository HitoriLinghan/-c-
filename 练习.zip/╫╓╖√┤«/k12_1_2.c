#include<stdio.h>
main()
{
	char s1[100],s2[100];
	int i;
	scanf("%s",s1);
	for(i=0;s2[i]=s1[i];i++)
	/*�����*/;
	printf("%s\n",s2);
}