#include<stdio.h>
main()
{
	double a[5]={8.6,6.8,5.6,4.9,1.1},t;
	int i;
	for(i=0;i<5/2;i++) 
	{t=a[i];a[i]=a[4-i];a[4-i]=t;}
	for(i=0;i<=4;i++)
	printf("%.1f,",a[i]);
	printf("\n");
}