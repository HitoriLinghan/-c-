#include<stdio.h>
main()
{
	double sum=0,aver,a[6];
	int i;
	for(i=0;i<=5;i++)
	scanf("%lf",&a[i]);
    for(i=0;i<=5;i++)
	sum=sum+a[i];
	aver=sum/6;
	printf("%f,%f\n",sum,aver);
	
}
	

