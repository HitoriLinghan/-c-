#include<stdio.h>
main()
{
	int i,a[10],min,t;
    for(i=0;i<=9;i++)
	scanf("%d",&a[i]);	
	min=0;
	for(i=0;i<=9;i++)
	if(a[min]>a[i]) min=i;
	if(min)
	{t=a[min];a[min]=a[0];a[0]=t;}
	for(i=0;i<=9;i++)
	printf("%d,",a[i]);
	printf("\n");
}



