#include<stdio.h>
main()
{
	int x[8],i,y[8],a,b,j=0;
	for(i=0;i<8;i++)
	scanf("%d",&x[i]);
	for(i=0;i<8;i++)
	{a=x[i]%10;
	b=x[i]/100%10;
	if(a==b) y[j++]=x[i];}
	for(i=0;i<j;i++)
	printf("%d,",y[i]);
	printf("\n");
}
	