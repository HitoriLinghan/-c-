#include<stdio.h>
main()
{
	int i,j,sum,k=0,a[1000];
	for(i=1;i<=1000;i++)
	{for(j=1,sum=0;j<i;j++)
	if(i%j==0) sum=sum+j;
	if(sum==i) a[k++]=i;}
	for(i=0;i<=k-1;i++)
	printf("%d,",a[i]);
	printf("\n");
	printf("%d\n",k);
}