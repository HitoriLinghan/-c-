#include<stdio.h>
main()
{
   int i,a[10],t;
   for(i=0;i<=9;i++)
   scanf("%d",&a[i]);
   for(i=0;i<10/2;i++)
   {t=a[i];a[i]=a[9-i];a[9-i]=t;}
   for(i=0;i<=9;i++)
	printf("%d,",a[i]);
   printf("\n");
}