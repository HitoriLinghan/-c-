#include<stdio.h>
main()
{
	int i,fib[20];
	fib[0]=fib[1]=1;
	for(i=2;i<=19;i++)
	fib[i]=fib[i-1]+fib[i-2];
	for(i=0;i<=19;i++)
	{printf("%6d,",fib[i]);
	if((i+1)%7==0) printf("\n");}
	printf("\n");
}
