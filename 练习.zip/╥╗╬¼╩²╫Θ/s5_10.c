#include<stdio.h>
main()
{
	double sum=0,aver,a[6]={88,95,80,87,82,60};
	int i;
	for(i=0;i<=5;i++)
	sum=sum+a[i];
	aver=sum/6;
	printf("%f\n",aver);
}
	