#include<stdio.h>
main()
{
	int i,j,k=0,a[100];
	for(i=200;i<=300;i++)
	{for(j=2;j<i;j++)
	 if(i%j==0) break;
	 if(i==j) a[k++]=i;}
	 for(i=0;i<=k-1;i++)
	 {printf("%d,",a[i]);
	 if((i+1)%5==0) printf("\n");}
	 printf("\n");
}




