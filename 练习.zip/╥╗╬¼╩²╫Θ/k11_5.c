#include<stdio.h>
main()
{
	int i,j=0,a[900],x,y,z;
    for(i=100;i<=999;i++)
	{
	x=i/100;
	y=i/10%10;
	z=i%10;
	if(x*x*x+y*y*y+z*z*z==i) {a[j]=i;j++;}
	}
	for(i=0;i<=j-1;i++)
	printf("%d,",a[i]);
	printf("\n");
	printf("%d\n",j);
}