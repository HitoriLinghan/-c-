#include<stdio.h>
main()
{
	int i,j=0,a[100];
	for(i=200;i<=300;i++)
	if(i%7==0) a[j++]=i;
	for(i=0;i<=j-1;i++)
	printf("%d,",a[i]);
	printf("\n");
	printf("��%d��\n",j);
}
    
