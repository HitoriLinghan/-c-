#include<stdio.h>
main()
{
	int a[7],b[7],c[7],i,j,k=0;
	for(i=0;i<7;i++)
		scanf("%d",&a[i]);
	for(j=0;j<7;j++)
		scanf("%d",&b[j]);
	for(i=0;i<7;i++)
	{for(j=0;j<7;j++)
	if(i==j) c[k++]=a[i]*10+b[j];}
	for(i=0;i<k;i++)
	printf("%d,",c[i]);
    printf("\n");
}