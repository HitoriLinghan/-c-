#include<stdio.h>
main()
{
	int a=5,b=4,c=3,m;
	m=a>b?a:b;
	m=a>c?a:c;
	printf("m=%d\n",m);
}
