#include<stdio.h>
main()
{
	double x=3.4568,a;
	x=(int)(x*10+0.5)%10;
	a=x/10;
	printf("%f",a);
}
