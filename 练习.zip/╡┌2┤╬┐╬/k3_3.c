#include<stdio.h>
main()
{
	char c='c';
	printf("%c,%c\n",c-1+'A'-'a',c+1);
}
