#include<stdio.h>
main()
{
   int i,b=1,f=0;
   for(i=1;i<=101;i++)
	if(i%2!=0) {f=f+i*b;b=-b;}
   printf("%d\n",f);
}