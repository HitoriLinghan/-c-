#include<stdio.h>
main()
{
	int n=1,t;
	double f=0;
	do
	{t=n*n;
	f=f+t;
	n++;}
	while(f<5500);
	printf("%d\n",n-2);
}