#include<stdio.h>
main()
{
	int i=1;
	while(i>=1&&i<=500)
	{if((i%7==0)&&(i%9)==0) printf("%d,",i) ;
	i++;}
	printf("\n");
}

