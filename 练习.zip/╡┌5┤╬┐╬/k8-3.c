#include<stdio.h>
main()
{
	int i;
	double s=1,f=0;
	for(i=1;i<=20;i++)
	{s=s*i;
	if(i%5==0) f=f+1/s;}
	printf("%.10f\n",f);
}


