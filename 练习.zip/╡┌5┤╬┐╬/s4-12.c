#include<stdio.h>
main()
{
	int i=1,n;
	double s=1;
	scanf("%d",&n);
	while(i<=n)
	{s=s*i;
	i++;}
	printf("%f\n",s);
}