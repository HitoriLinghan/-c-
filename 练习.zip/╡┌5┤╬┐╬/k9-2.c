#include<stdio.h>
main()
{
int i=100,a,b,c,sum=0;
while(i>=100&&i<=999)
{a=i/100;
b=i/10%10;
c=i%10;
if(a*a*a+b*b*b+c*c*c==i) sum=sum+i;
i++;}
printf("%d\n",sum);
}