#include<stdio.h>
main()
{
	int i=100,count=0;
	while(i>=100&&i<=200)
	{if(i%3!=0)
	{printf("%d,",i);
	count++;
	if(count%5==0) printf("\n");}
	i++;}
	printf("\n");
}
