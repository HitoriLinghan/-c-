#include<stdio.h>
main()
{
	int n,i=1;
	double s=1,f=1;
	scanf("%d",&n);
	while(i<=n)
	{s=s*i;
	if(i%5==0)f=f+s;
	i++;}
	printf("%f\n",f);
}
