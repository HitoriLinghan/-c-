#include<stdio.h>
main()
{
double e=1,s=1,i=1;
while(i<1E6)
{s=s*i;
e=e+1/s;
i++;}
printf("%f\n",e);
}