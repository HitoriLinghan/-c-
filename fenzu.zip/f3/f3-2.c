#include<stdio.h>
int main()
{char a,b;
a=getchar();
b=getchar();
putchar(a+1);
printf("\n");
putchar(b-'a'+'A');
printf("\n");

 	return 0;
}
