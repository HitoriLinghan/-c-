#include<stdio.h>
int main()
{int a,b;
a=15;
b=-9;
printf("%d+(%d)=%f\n",a,b,(double)a+b);
printf("%d-(%d)=%f\n",a,b,(double)a-b);
printf("%d*(%d)=%f\n",a,b,(double)a*b);
printf("%d/(%d)=%f\n",a,b,(double)a/b);
printf("%d%(%d)=%d\n",a,b,a%b);
 	return 0;
}
