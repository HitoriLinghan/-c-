#include<stdio.h>
int main()
{int flag=1,i,n,t=1;
double sum=0;
scanf("%d",&n);
for(i=1;i<=n;i++)
{sum=sum+flag*1.0/(3*i-2);
flag=-flag;
}
printf("sum=%.3f",sum);
 	return 0;
}
