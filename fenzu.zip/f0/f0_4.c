#include<stdio.h>
int main()
{double x,y,z,t;
scanf("%lf %lf %lf",&x,&y,&z);
if(y>x)
{t=x;x=y;y=t;}
if(z>x)
{t=x;x=z;z=t;}
if(z>y)
{t=y;y=z;z=t;}
printf("%f,%f,%f",x,y,z);

 	return 0;
}
