#include<stdio.h>
#include<string.h>
int main()
{
    char s[90];
    int j,len;
    int a,e,i,o,u,A,E,I,O,U;
	printf("input a sting:\n");
    a=e=i=o=u=A=I=E=O=U=0;
    gets(s);
    len=strlen(s);
    for(j=0;j<len;j++)
    {
        if(s[j]=='a'||s[j]=='A') a++;
        else if(s[j]=='e'||s[j]=='E') e++;
        else if(s[j]=='i'||s[j]=='I') i++;
        else if(s[j]=='o'||s[j]=='O') o++;
        else if(s[j]=='u'||s[j]=='U') u++;
    }
	printf("A,E,I,O,U,\n");
    printf("%d,%d,%d,%d,%d\n",a,e,i,o,u);
    return 0;
}
