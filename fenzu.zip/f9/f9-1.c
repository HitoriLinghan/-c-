#include<stdio.h>
#include<string.h>
main()
{char c[100],t;
int i,l;
gets(c);
l=strlen(c);
for(i=0;i<l/2;i++)
{t=c[i];
c[i]=c[l-1-i];
c[l-1-i]=t;

}

puts(c);

}
