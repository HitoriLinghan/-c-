#include<stdio.h>
main()
{
  int n,i;
  int feibola(int);
  scanf("%d",&n);
  for(i=0;i<n;i++)
	  printf("%d,",feibola(i));
  printf("\n");
}
int feibola(int n)
{   int t;
   if(n==0||n==1)t=1;
    else t=feibola(n-1)+feibola(n-2);
    return t;
}