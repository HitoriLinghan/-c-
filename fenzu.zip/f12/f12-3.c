//注意必须使用递归函数gys()
#include <stdio.h>
main()
{
	int a,b;
	int gys(int,int );
	printf("Input a,b:");	
	scanf("%d,%d", &a,&b);
	if (a<=0||b<=0)printf("Input error!\n");
	else
		printf("%d\n",gys(a,b));
}
int gys(int a,int b)
{int r,g;
r=a%b;
if(r==0)g=b;
else g=gys(b,r);
return g;
}