#include<stdio.h>
main()
{
  int n,f;
  int huiwen(int );
  scanf("%d",&n);
  f=huiwen(n);
  if(f)printf("%d is a Palindrome.\n",n);
  else printf("%d isn't a Palindrome.\n",n);
}

int huiwen(int n)
{int i=0,f,t;
t=n;
while(n)
{i=i*10+n%10;
n/=10;
}
if(i==t)f=1;
else f=0;
return f;
}
