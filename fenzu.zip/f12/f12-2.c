#include<stdio.h>
#include<string.h>
main()
{
	char s[100];
	int huiwen(char s[]);
	int f=1;
	gets(s);
    f=huiwen(s);
	if(f)printf("%s is a Palindrome.\n",s);
	else printf("%s isn't a Palindrome.\n",s);
}

int huiwen(char s[])
{
  int i,l,f=1;
  l=strlen(s);
  for(i=0;i<=l/2;i++)
  {if(s[i]!=s[l-1-i])f=0;
  }
  return f;
}