#include<stdio.h>
int main()
{
	int score[10],index_max=0,i,max,min,index_min=0;
	 printf("输入十个成绩：\n"); 
	 for(i=0;i<10;i++)
	 {
	 	scanf("%d",&score[i]);
	 } 
	for (i=0;i<10;i++)
	
		
	
	printf("\n");
	min=max=score[0];
	for(i=1;i<10;i++)
	{
		if(max<score[i])
		{
			max=score[i];
			index_max=i;
		}
		if(min>score[i])
		{
			min=score[i];
			index_min=i;
		}
		
	}	 
 printf("最高分是%d\n",max);
 printf("最低分是%d\n",min);
 
 
 
 
 } 
