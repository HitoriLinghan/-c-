#include <stdio.h>
#include <math.h>
main()
{
int i;
double s=0,a=81;
for(i=1;i<=25;i++){
s=s+a;
a=sqrt(a);
}
printf("%f\n",s);
 } 
