#include<stdio.h>
#include<stdlib.h>
main()
{
    int ComputeAge(int );
    int n,f;
    scanf("%d",&n);
    f=ComputeAge(n);
    printf("The age:%d\n",f);
}

int ComputeAge(int n)
{
if(n==1)n=10;
else n=ComputeAge(n-1)+2;
return n;
}