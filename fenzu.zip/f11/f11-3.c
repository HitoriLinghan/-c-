#include<stdio.h>
main()
{
  char c1[100],c2[100],c3[200];
  void func(char c1[],char c2[],char c3[]);
  gets(c1);
  gets(c2);
  func(c1,c2,c3);
  puts(c3);
}

void func(char c1[],char c2[],char c3[])
{int i,j;
for(i=0;c1[i];i++)c3[i]=c1[i];
for(j=0;c2[j];i++,j++)c3[i]=c2[j];
  
}