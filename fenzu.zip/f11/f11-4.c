#include<stdio.h>
main()
{
  int a[100],m,i;
  int func(int a[]);
  m=func(a);
  for(i=0;i<m;i++)
	  printf("%d,",a[i]);
  printf("\n");
}

int func(int a[])
{int k=0,t,i;
for(i=100;i<=200;i++)
{for(t=2;t<i;t++){if(i%t==0)break;
}
if(t==i)a[k++]=i;
}
return k;
}
