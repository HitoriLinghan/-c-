#include<stdio.h>
main()
{
  int a[100],n,m,i;
  int func(int a[],int );
  scanf("%d",&n);
  m=func(a,n);
  for(i=0;i<m;i++)
	  printf("%d,",a[i]);
  printf("\n");
}

int func(int a[],int n){
	int i,j=0;
		for(i=1;i<=n;i++)
  if(i<n&&i%2==1)a[j++]=i;
  return j; 
}
