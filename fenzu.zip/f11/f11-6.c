#include <stdio.h>
#include <string.h>
void Caesar(char c1[], char c2[]);
void Caesar(char c1[], char c2[])
{
	int i, l;
	l = strlen(c1);
	for (i = 0; i < l; i++)
	{
		if (c1[i] >= 'a' && c1[i] <= 'z' || c1[i] >= 'A' && c1[i] <= 'Z')
		{
			if (c1[i] == 'x')
				c2[i] = 'a';
			else if (c1[i] == 'y')
				c2[i] = 'b';
			else if (c1[i] == 'z')
				c2[i] = 'c';
			else
				c2[i] = c1[i] + 3;
		}
		else
			c2[i] = c1[i];
	}
	c2[i] = 0;
}
main()
{
	char s1[100], s2[100];
	printf("Input a string:");
	gets(s1);
	Caesar(s1, s2);
	puts(s2);
}