#include<stdio.h>
main()
{
  int a,b,c,d,max;
  int func(int ,int );
  scanf("%d%d%d%d",&a,&b,&c,&d);
  max=func(a,b);
  max=func(max,c);
  max=func(max,d);
  printf("The max:%d\n",max);
 }

int func(int x,int y)
{
if(x>y)return x;
else return y; 
}

