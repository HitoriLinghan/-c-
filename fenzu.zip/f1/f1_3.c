#include<stdio.h>
int main()
{int a,b,c,x,y;
scanf("%2d%2d %d",&a,&b,&c);
x=a+c/60;
y=b+c%60;
if(y>=60){y=y%60;x=x+1;
}
printf("%2d%2d,%2d%2d",a,b,x,y);
 	return 0;
}
