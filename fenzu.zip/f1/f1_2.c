#include<stdio.h>
int main()
{int cm,foot,inch;
scanf("%d",&cm);
foot=cm/30.48;
inch=(cm/30.48-foot)*12;
printf("input:%d,foot:%d,inch:%d",cm,foot,inch);
 	return 0;
}
