#include<stdio.h>
int main()
{

	int m, n, a, b, i, j;
	scanf("%d%d", &m, &n);
	if (m < n)
	{
		b = m;
		m = n;
		n = b;
	}
	i = m;
	j = n;
	while (n != 0)
	{
		a = m % n;
		m = n;
		n = a;
	}
	printf("������: %d\n", m);
	printf("��Լ��: %d\n", i * j / m);

 	return 0;
}
