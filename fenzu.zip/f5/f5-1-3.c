#include<stdio.h>
int main()
{

	int n,i=1,f=1;
    double s=1,e=0;
	scanf("%d",&n);
	while(i<=n)
	{
		s=s*i;
		if(i%3==0)e=e+f*s/100;
		i++;
		f=-f;
	}
	printf("%f\n",e);
 	return 0;
}
