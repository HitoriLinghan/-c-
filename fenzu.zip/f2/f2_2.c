#include<stdio.h>
int main()
{int x;
printf("input1-7:");
scanf("%d",&x);
if(x>1)printf("20day later is:%d",x-1);
else printf("20day later is:%d",x+6);



 	return 0;
}
