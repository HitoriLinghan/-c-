#include<stdio.h>
int main()
{double a,b,c,max;
scanf("%lf %lf %lf",&a,&b,&c);
max=a>b?a:b;
max=a>c?a:c;
max=c>b?c:b;
max=(int)(max*10)/10.0;
printf("%f\n",max);
 	return 0;
}
