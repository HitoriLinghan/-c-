#include<stdio.h>
#define MAX 20
main()
{
	int a[MAX],i,j,n;
	for(i=0;i<MAX;i++)
		scanf("%d",&a[i]);
	n=i=MAX-1;
	while(i>=0)
	{
		if(a[i]==a[i-1])
		{
			for(j=i;j<=n;j++)
				a[j-1]=a[j];
			n=n-1;
		}
		i=i-1;
	}
	for(i=0;i<=n;i++)
	{
		if(i%5==0)printf("\n");
	printf("%d,",a[i]);
	}
	printf("\n");
}