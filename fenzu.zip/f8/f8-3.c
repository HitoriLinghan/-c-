#include<stdio.h>
main()
{int a[10],b[10],i,j,m=0;
for(i=0;i<10;i++)scanf("%d",a+i);
for(i=0;i<10;i++)
{
	for(j=2;j<a[i];j++)
		if(a[i]%j==0)break;
		if(j>=a[i]) b[m++]=a[i];
}
    for(i=0;i<m;i++)printf("%d,",b[i]);
    printf("��%d��\n",m);
}