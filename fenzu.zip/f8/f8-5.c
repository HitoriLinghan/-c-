#include<stdio.h>
int main()
{
	int m,n,a[10],i,k,t;
	printf("输入m,n的值:");
	scanf("%d,%d",&m,&n);
	for(i=0;i<m;i++)
	{a[i]=i+1;}//这一步是赋值，第n个是n
	i=k=t=0;
	while(t<m)
	{
		if(a[i]!=0)//一定循环
		{
			k++;//代表第几项
			if(k%n==0)
			{
				printf("%d,",a[i]);
				t++;//出去几个
				a[i]=0;//代表这一个是空
			}
		}
		i++;
		if(i==m) i=0;
	}
	printf("\n");
}
