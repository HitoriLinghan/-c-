#include<stdio.h>
int main()
{
	int i, j, k, m;
	int a[10];
	for (i = 0; i < 10; i++)
		scanf("%d",&a[i]);
	for (i = 0; i < 10; i++)
	{
		k = i;
		for (j = i + 1; j < 10; j++)
		{
			if (a[j] > a[k])
				k = j;
		}
		if (k != i)
		{
			m=a[i];
			a[i] = a[k];
			a[k] = m;
		}
	}
	for (i = 1; i<10; i++)
		printf("%d,", a[i]+1);
	printf("\n");
	return 0;
}
