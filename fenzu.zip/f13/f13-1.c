#include<stdio.h>
int a;
main()
{   
    char str[100];
	void change(char s[]);
    gets(str);
    change(str);   
    printf("The value:%d\n",a);
}

void change(char s[])
{  int i;

for(i=0;s[i];i++)
if(s[i]>='0'&&s[i]<='9')a=a*10+s[i]-'0';

}
