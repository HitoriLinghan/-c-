#include<stdio.h>
double mypow(double x,int n)
{ double t=1;
if(n==0)t=1;
else if(t>0)t=mypow(x,n-1)*x;
else if(t<0)t=1/x*mypow(x,n+1);
return t;

}
void main()
{
  double x;
  int n;
  printf("input x,n:");
  scanf("%lf,%d",&x,&n);
  printf("%f\n",mypow(x,n));
}